README

To compile code, open the .sln file in Visual Studio and build and run the project.


Alternatively, you could go to the bin/debug directory to find the executable and run it that way.